% function convert_T_LIDAR_from_txt_to_mat()
% converts the lidar time to a mat file. This function is only run once
% before running MAIN


% open and read the text file
%fileID= fopen('ouster_frames_timestamps.txt','r');
filename= 'ouster_frames_timestamps.txt';
file= csvimport(filename);
T_LIDAR= cell2mat(file(2:end,:));
% substract the days from the time
timestamps_in_days= T_LIDAR(:,2) / (60*60*24);
T_LIDAR(:,2)= ( timestamps_in_days - fix(timestamps_in_days) ) *60*60*24;

% Add half the difference to the next scan to obtain the time at the middle
% of the scan (the one loaded directly is the time at the beginning of the
% scan)
diff_T= diff(T_LIDAR(:,2)) / 2;
diff_T= [diff_T; mean(diff_T)];
T_LIDAR(:,2)= T_LIDAR(:,2) + diff_T;
save('T_LIDAR.mat','T_LIDAR');
